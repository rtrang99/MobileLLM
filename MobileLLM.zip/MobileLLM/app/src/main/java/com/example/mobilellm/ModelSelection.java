package com.example.mobilellm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;

public class ModelSelection extends AppCompatActivity {
    Button button1;
    Button button2;
    Button button3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_model_selection);
        // Get View IDs from xml
        button1 = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        // Button 1 has been clicked
        button1.setOnClickListener(view -> {
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(ModelSelection.this, loading.class);
                startActivity(intent);
                finish();
            }, 500);
        });
        // Button 2 has been clicked
        button2.setOnClickListener(view -> {
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(ModelSelection.this, loading.class);
                startActivity(intent);
                finish();
            }, 500);
        });
        // Button 3 has been clicked
        button3.setOnClickListener(view -> {
            new Handler().postDelayed(() -> {
                Intent intent = new Intent(ModelSelection.this, loading.class);
                startActivity(intent);
                finish();
            }, 500);
        });
    }
}