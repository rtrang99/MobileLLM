package com.example.mobilellm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Toast;

import com.example.mobilellm.databinding.ActivityMainBinding;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity {
    // Posts data to a server
    public static final MediaType JSON = MediaType.get("application/json");

    OkHttpClient client = new OkHttpClient();
    // Used to load the 'mobilellm' library on application startup.
    static {
        System.loadLibrary("mobilellm");
    }
    private ActivityMainBinding binding;
    RecyclerView recyclerView;
    List<Message> messageList;
    MessageAdapter messageAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Set up recycler view
        recyclerView = findViewById(R.id.recyclerview);
        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList);
        recyclerView.setAdapter(messageAdapter);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        recyclerView.setLayoutManager(llm);


//UNCOMMENT TO TEST        // Clicking send button
//UNCOMMENT TO TEST        binding.sendbtn.setOnClickListener(view -> {
//UNCOMMENT TO TEST            String question = binding.msgbox.getText().toString().trim();
//UNCOMMENT TO TEST            Toast.makeText(this,question,Toast.LENGTH_LONG).show();
//UNCOMMENT TO TEST            addToChat(question,Message.SENT_BY_ME);
//UNCOMMENT TO TEST            binding.msgbox.setText("");
//UNCOMMENT TO TEST            callAPI(question);
//UNCOMMENT TO TEST        });
            binding.sendbtn.setOnClickListener(view -> {
                String question = binding.msgbox.getText().toString().trim();
                Toast.makeText(this, question, Toast.LENGTH_LONG).show();
                // insert c++
//                String transcript = addFormatting(messageList) + question;
//                question = stringFromJNI();
                addToChat(question, Message.SENT_BY_ME);
                binding.msgbox.setText("");
//                binding.msgbox.setText(addFormatting(messageList));
            });

            binding.dummy.setOnClickListener(view -> {
                String AI_answer = binding.msgbox.getText().toString().trim();
//                String transcript2 = addFormatting(messageList) + AI_answer;
                Toast.makeText(this, AI_answer, Toast.LENGTH_LONG).show();
                addToChat(AI_answer, Message.SENT_BY_BOT);
                //addToChat(messageList.get(1).message, Message.SENT_BY_BOT);
                binding.msgbox.setText("");
//                binding.msgbox.setText(addFormatting(messageList));
            });
        // Example of a call to a native method
//        TextView tv = binding.sampleText;
//        tv.setText(stringFromJNI());
    }
    void addToChat(String message, String sentBy){
        runOnUiThread(() -> {
            messageList.add(new Message(message,sentBy));
            messageAdapter.notifyDataSetChanged();
            recyclerView.smoothScrollToPosition(messageAdapter.getItemCount());
        });
    }
    String addFormatting(List<Message> messageList ){
        String test = "";
        String header;
        for(int i = 0; i < messageList.size(); i++){
            if(i % 2 == 1){
                header = "<bot>: ";
            }
            else {
                header = "<human>: ";
            }
            test = (header + messageList.get(i).message + "\n");

            //test = Integer.toString(messageList.size());
        }
        return test;
    }
    void addResponse(String response){
        addToChat(response,Message.SENT_BY_BOT);
    }
//UNCOMMENT TO TEST CHATGPT    void callAPI(String question){
//UNCOMMENT TO TEST CHATGPT        // okhttp
//UNCOMMENT TO TEST CHATGPT        JSONObject jsonBody = new JSONObject();
//UNCOMMENT TO TEST CHATGPT        try {
//UNCOMMENT TO TEST CHATGPT            JSONArray messagesArray = new JSONArray();
//UNCOMMENT TO TEST CHATGPT            JSONObject messageObject = new JSONObject();
//UNCOMMENT TO TEST CHATGPT            messageObject.put("role", "user");
//UNCOMMENT TO TEST CHATGPT            messageObject.put("content", question);
//UNCOMMENT TO TEST CHATGPT            messagesArray.put(messageObject);
//UNCOMMENT TO TEST CHATGPT            jsonBody.put("model","gpt-3.5-turbo-0613");
//UNCOMMENT TO TEST CHATGPT            jsonBody.put("messages", messagesArray);
//UNCOMMENT TO TEST CHATGPT            jsonBody.put("max_tokens", 4000);
//UNCOMMENT TO TEST CHATGPT            jsonBody.put("temperature",0);
//UNCOMMENT TO TEST CHATGPT        }catch (JSONException e) {
//UNCOMMENT TO TEST CHATGPT            throw new RuntimeException(e);
//UNCOMMENT TO TEST CHATGPT        }
//UNCOMMENT TO TEST CHATGPT        RequestBody body = RequestBody.create(jsonBody.toString(),JSON);
//UNCOMMENT TO TEST CHATGPT        Request request = new Request.Builder()
//UNCOMMENT TO TEST CHATGPT                .url("https://api.openai.com/v1/completions")
//UNCOMMENT TO TEST CHATGPT                .header("Authorization", "Bearer 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")
//UNCOMMENT TO TEST CHATGPT                .post(body)
//UNCOMMENT TO TEST CHATGPT                .build();
//UNCOMMENT TO TEST CHATGPT        client.newCall(request).enqueue(new Callback() {
//UNCOMMENT TO TEST CHATGPT            @Override
//UNCOMMENT TO TEST CHATGPT            public void onFailure(@NonNull Call call, @NonNull IOException e) {
//UNCOMMENT TO TEST CHATGPT                addResponse("Failed to load response due to " + e.getMessage());
//UNCOMMENT TO TEST CHATGPT            }
//UNCOMMENT TO TEST CHATGPT
//UNCOMMENT TO TEST CHATGPT            @Override
//UNCOMMENT TO TEST CHATGPT            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
//UNCOMMENT TO TEST CHATGPT                if (response.isSuccessful()) {
//UNCOMMENT TO TEST CHATGPT                    JSONObject jsonObject;
//UNCOMMENT TO TEST CHATGPT                    try {
//UNCOMMENT TO TEST CHATGPT                        assert response.body() != null;
//UNCOMMENT TO TEST CHATGPT                        JSONObject jsonObject2 = new JSONObject(response.body().string());
//UNCOMMENT TO TEST CHATGPT                        JSONArray jsonArray = jsonObject2.getJSONArray("choices");
//UNCOMMENT TO TEST CHATGPT                        String result = jsonArray.getJSONObject(0).getJSONObject("message").getString("content");
//UNCOMMENT TO TEST CHATGPT                        addResponse(result.trim());
//UNCOMMENT TO TEST CHATGPT                    } catch (JSONException e) {
//UNCOMMENT TO TEST CHATGPT                        throw new RuntimeException(e);
//UNCOMMENT TO TEST CHATGPT                    }
//UNCOMMENT TO TEST CHATGPT                } else {
//UNCOMMENT TO TEST CHATGPT                    addResponse("Failed to load response due to " + response.body().string());
//UNCOMMENT TO TEST CHATGPT                }
//UNCOMMENT TO TEST CHATGPT            }
//UNCOMMENT TO TEST CHATGPT        });
//UNCOMMENT TO TEST CHATGPT    }
    /**
     * A native method that is implemented by the 'mobilellm' native library,
     * which is packaged with this application.
     */
    public native String stringFromJNI();
}