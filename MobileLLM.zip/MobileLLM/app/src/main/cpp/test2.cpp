//
// Created by  on 3/5/2024.
//

#include "test2.h"

int mySub(int a, int b) {
    return a - b;
}
