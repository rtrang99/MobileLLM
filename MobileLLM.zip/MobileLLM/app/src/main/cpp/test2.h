//
// Created by  on 3/5/2024.
//

#ifndef MOBILELLM_TEST2_H
#define MOBILELLM_TEST2_H
int mySub(int a, int b);
#endif //MOBILELLM_TEST2_H
