#ifndef TEST3_H
#define TEST3_H
int myMul(int a, int b);
#endif

// /home/kernal1/android-ndk-r19c/build/ndk-build