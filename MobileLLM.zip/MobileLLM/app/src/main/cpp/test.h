#ifndef TEST_H_
#define TEST_H_
 int main_2(int argc, char* argv[]);
//int main_2(int argc, char* argv[]){
//    return 1;
//}
#endif