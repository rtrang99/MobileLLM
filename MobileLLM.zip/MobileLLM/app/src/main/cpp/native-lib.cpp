#include <jni.h>
#include <string>
#include <sstream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>

class Motor {
public:
    int model;
    int price;
    Motor(int m, int p);
    bool Validate();
    // int vec_size = 5000000000; // also try with 1000000000
    int vec_size = 1000000000; // 100M = 100000000 1G = 1000000000
    //std::vector<int> vec = std::vector<int>(vec_size);
    int vec[1000000000];
    int vec_size_2 = 250000000;
    int vec2[250000000];
};
Motor::Motor(int m, int p) {
    model = m;
    for (long i = long(0); i < vec_size; i++) {
        vec[i] = i;
    }
    for (long i = long(0); i < vec_size_2; i++) {
        vec2[i] = i;
    }
    price = p;

}
bool Motor::Validate() {
    bool correct = true;
    for (long i = long(0); i < vec_size; i++) {
        correct = correct && (vec[i] == i);
    }
    for (long i = long(0); i < vec_size_2; i++) {
        correct = correct && (vec2[i] == i);
    }
    return correct;
}


extern "C" JNIEXPORT jstring JNICALL
Java_com_example_mobilellm_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    static Motor* ptr = new Motor(4,5);
    bool valid = ptr->Validate();
    //Motor m = Motor(4,5);
    //bool valid = m.Validate();
    //return env-> NewStringUTF(std::to_string(sizeof (int)).c_str());
    return env->NewStringUTF(std::to_string(int(valid)).c_str());
}